#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 -m unittest -v test_integrated.py
python3 integrated_stress.py "$@"
